import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mission-show',
  templateUrl: './mission-show.page.html',
  styleUrls: ['./mission-show.page.scss'],
})
export class MissionShowPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
